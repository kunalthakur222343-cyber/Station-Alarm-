# Station Alarm — Setup Guide

Ye project Android Studio mein khol ke directly run kiya ja sakta hai.

## 1. Project kholna
1. Android Studio install kar (agar nahi hai) — https://developer.android.com/studio
2. "Open" → `StationAlarm` folder select kar
3. Gradle sync hone do (pehli baar thoda time lega)

## 2. Google Maps API Key lagana (ZAROORI — isके bina map nahi dikhega)
1. https://console.cloud.google.com pe jaa, naya project bana
2. "APIs & Services" → "Library" → "Maps SDK for Android" enable kar
3. "Credentials" → "Create Credentials" → "API Key"
4. `app/src/main/AndroidManifest.xml` kholo, ye line dhoondo:
   ```
   android:value="YOUR_GOOGLE_MAPS_API_KEY_HERE"
   ```
   Apni key yahan paste kar de.

## 3. App ke launcher icon
Default Android Studio project template mein `ic_launcher` icons already aate hain. Agar missing error aaye:
- `res/mipmap` folders Android Studio ke "New > Image Asset" wizard se generate kar lena (right-click `res` → New → Image Asset)

## 4. Run karna
1. Phone ko USB se connect kar (Developer Options + USB Debugging on kar ke), ya Emulator use kar
2. Top mein green "Run" button daba
3. App pehli baar khulte hi sequence mein permissions maangega:
   - Location (Fine + Coarse)
   - Background location ("Allow all the time") — **YE SABSE IMPORTANT HAI**, isse hi phone lock hone ke baad bhi tracking chalti hai
   - Notifications
   - Battery optimization se exempt karne ka popup — "Allow" zaroor karna, warna kuch phones (Xiaomi/Oppo/Vivo) app ko background mein kill kar denge

## 5. Use kaise kare
1. **Search bar** mein station/stop ka naam type kar (Places autocomplete khulega), ya seedha map pe tap kar
2. "Save this station for later" daba ke frequently used stops save kar le — agli baar history icon (🕐) se ek tap mein select ho jayenge
3. "Start Trip Alarm" daba
4. Phone so jaa de, lock kar de — koi problem nahi
5. Jab destination ~10 min door hoga, ek pre-alert notification aayegi
6. Jab destination 500m ke andar aayega, full-screen LOUD alarm bajega (silent mode mein bhi), screen lock hote hue bhi on ho jayegi

## Naye features (Places search + saved stations)
- Search bar pe tap karne se Google Places Autocomplete full-screen khulta hai — station/stop ka naam type karo, list se select karo
- "Save this station for later" se current selection Room DB mein save ho jata hai
- History icon (🕐) dabane se saved stations ki list khulti hai — tap karke select, delete icon se remove
- Recently used station automatically list mein upar aata hai (last-used timestamp ke hisaab se sort)

## Important notes — Xiaomi/Oppo/Vivo/Realme phones
Ye brands apna khud ka aggressive battery management karte hain jo Android ke standard rules ko bypass karte hain. Agar app background mein band ho jaye:
- Settings → Apps → Station Alarm → Battery → "No restrictions" / "Allow background activity"
- MIUI: Security app → Permissions → Autostart → Station Alarm ON kar do

## Production ke liye aage ke steps (jab ready ho launch karne ke liye)
- Places Autocomplete add karna (taaki user station ka naam type karke search kar sake, sirf map tap na ho)
- Saved/favorite stations list (Room DB already add kiya hai dependencies mein)
- Multiple alarm profiles (different routes ke liye)
- Play Store pe publish karne se pehle: privacy policy banani padegi (kyunki background location use ho raha hai — Google iske liye strict review karta hai)
