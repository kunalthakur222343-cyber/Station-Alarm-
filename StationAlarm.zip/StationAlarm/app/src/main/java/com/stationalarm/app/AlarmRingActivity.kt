package com.stationalarm.app

import android.app.KeyguardManager
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton
import androidx.appcompat.widget.AppCompatTextView
import android.widget.LinearLayout
import android.view.Gravity
import android.graphics.Color

class AlarmRingActivity : AppCompatActivity() {

    private var mediaPlayer: MediaPlayer? = null
    private var vibrator: Vibrator? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Force the screen on and show over the lock screen — this is what
        // actually wakes a sleeping passenger up
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        window.addFlags(
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
            WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
            WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
        )

        val keyguardManager = getSystemService(KEYGUARD_SERVICE) as KeyguardManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            keyguardManager.requestDismissKeyguard(this, null)
        }

        val destinationName = intent.getStringExtra("destination_name") ?: "your stop"

        buildSimpleUi(destinationName)
        playAlarmSound()
        startVibration()
    }

    /**
     * Built programmatically (no XML layout needed) — big text + big dismiss button,
     * designed to be readable/tappable by someone half-asleep.
     */
    private fun buildSimpleUi(destinationName: String) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#D32F2F"))
            setPadding(48, 48, 48, 48)
        }

        val title = AppCompatTextView(this).apply {
            text = "WAKE UP!"
            textSize = 36f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }

        val subtitle = AppCompatTextView(this).apply {
            text = "$destinationName has arrived"
            textSize = 20f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 64)
        }

        val dismissButton = AppCompatButton(this).apply {
            text = "TAP TO DISMISS ALARM"
            textSize = 20f
            setPadding(32, 48, 32, 48)
            setOnClickListener { stopAlarmAndFinish() }
        }

        root.addView(title)
        root.addView(subtitle)
        root.addView(dismissButton)
        setContentView(root)
    }

    private fun playAlarmSound() {
        // Force the ALARM stream to maximum volume — even if user had it turned down,
        // this guarantees full loudness when it matters most
        val audioManager = getSystemService(AUDIO_SERVICE) as android.media.AudioManager
        val maxVolume = audioManager.getStreamMaxVolume(android.media.AudioManager.STREAM_ALARM)
        audioManager.setStreamVolume(android.media.AudioManager.STREAM_ALARM, maxVolume, 0)

        val alarmUri = android.media.RingtoneManager.getActualDefaultRingtoneUri(
            this, android.media.RingtoneManager.TYPE_ALARM
        )
        mediaPlayer = MediaPlayer().apply {
            setAudioAttributes(
                AudioAttributes.Builder()
                    // STREAM_ALARM ignores the ringer/silent mode setting — this is
                    // the key trick that makes it bypass "silent mode"
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            setDataSource(this@AlarmRingActivity, alarmUri)
            isLooping = true
            prepare()
            start()
        }
    }

    private fun startVibration() {
        vibrator = getSystemService(VIBRATOR_SERVICE) as Vibrator
        // Strong, near-continuous pattern: short gaps so it feels relentless
        val pattern = longArrayOf(0, 1000, 200, 1000, 200, 1000, 200)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator?.vibrate(VibrationEffect.createWaveform(pattern, 0))
        } else {
            @Suppress("DEPRECATION")
            vibrator?.vibrate(pattern, 0)
        }
    }

    private fun stopAlarmAndFinish() {
        mediaPlayer?.stop()
        mediaPlayer?.release()
        vibrator?.cancel()
        finish()
    }

    override fun onDestroy() {
        super.onDestroy()
        mediaPlayer?.release()
        vibrator?.cancel()
    }

    // Prevent back button from silently dismissing the alarm
    override fun onBackPressed() {
        // no-op: user must tap Dismiss
    }
}
