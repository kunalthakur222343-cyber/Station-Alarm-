package com.stationalarm.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build

class StationAlarmApp : Application() {

    companion object {
        const val TRACKING_CHANNEL_ID = "tracking_channel"
        const val ALARM_CHANNEL_ID = "alarm_channel"
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)

            // Silent, low-priority channel for the persistent "tracking active" notification
            val trackingChannel = NotificationChannel(
                TRACKING_CHANNEL_ID,
                "Trip Tracking",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows that your journey is being tracked"
                setShowBadge(false)
            }

            // High-priority, loud channel for the actual wake-up alarm
            val alarmChannel = NotificationChannel(
                ALARM_CHANNEL_ID,
                "Station Alarm",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Alerts you when your station is approaching"
                enableVibration(true)
                setBypassDnd(true)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            }

            manager.createNotificationChannel(trackingChannel)
            manager.createNotificationChannel(alarmChannel)
        }
    }
}
