package com.stationalarm.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            val prefs = context.getSharedPreferences("trip_prefs", Context.MODE_PRIVATE)
            val isTripActive = prefs.getBoolean("trip_active", false)
            if (isTripActive) {
                val name = prefs.getString("dest_name", null) ?: return
                val lat = prefs.getFloat("dest_lat", 0f).toDouble()
                val lng = prefs.getFloat("dest_lng", 0f).toDouble()
                val preAlertMin = prefs.getInt("pre_alert_min", 10)
                val arrivalRadius = prefs.getFloat("arrival_radius", 500f).toDouble()

                val serviceIntent = Intent(context, LocationTrackingService::class.java).apply {
                    action = LocationTrackingService.ACTION_START
                    putExtra(LocationTrackingService.EXTRA_DEST_NAME, name)
                    putExtra(LocationTrackingService.EXTRA_DEST_LAT, lat)
                    putExtra(LocationTrackingService.EXTRA_DEST_LNG, lng)
                    putExtra(LocationTrackingService.EXTRA_PRE_ALERT_MIN, preAlertMin)
                    putExtra(LocationTrackingService.EXTRA_ARRIVAL_RADIUS, arrivalRadius)
                }
                context.startForegroundService(serviceIntent)
            }
        }
    }
}
