package com.stationalarm.app

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.location.Location
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.google.android.gms.location.*
import com.stationalarm.app.model.Destination
import kotlin.math.roundToInt

class LocationTrackingService : Service() {

    companion object {
        const val ACTION_START = "ACTION_START_TRACKING"
        const val ACTION_STOP = "ACTION_STOP_TRACKING"
        const val EXTRA_DEST_NAME = "extra_dest_name"
        const val EXTRA_DEST_LAT = "extra_dest_lat"
        const val EXTRA_DEST_LNG = "extra_dest_lng"
        const val EXTRA_PRE_ALERT_MIN = "extra_pre_alert_min"
        const val EXTRA_ARRIVAL_RADIUS = "extra_arrival_radius"
        const val NOTIFICATION_ID = 1001

        const val BROADCAST_TRIP_UPDATE = "com.stationalarm.app.TRIP_UPDATE"
        const val EXTRA_DISTANCE = "extra_distance"
        const val EXTRA_ETA = "extra_eta"
    }

    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private var wakeLock: PowerManager.WakeLock? = null
    private var destination: Destination? = null

    private var preAlertFired = false
    private var finalAlarmFired = false

    private val recentSpeeds = mutableListOf<Double>()

    private val locationCallback = object : LocationCallback() {
        override fun onLocationResult(result: LocationResult) {
            result.lastLocation?.let { handleNewLocation(it) }
        }
    }

    override fun onCreate() {
        super.onCreate()
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val name = intent.getStringExtra(EXTRA_DEST_NAME) ?: "Destination"
                val lat = intent.getDoubleExtra(EXTRA_DEST_LAT, 0.0)
                val lng = intent.getDoubleExtra(EXTRA_DEST_LNG, 0.0)
                val preAlertMin = intent.getIntExtra(EXTRA_PRE_ALERT_MIN, 10)
                val arrivalRadius = intent.getDoubleExtra(EXTRA_ARRIVAL_RADIUS, 500.0)

                destination = Destination(name, lat, lng, preAlertMin, arrivalRadius)
                preAlertFired = false
                finalAlarmFired = false
                recentSpeeds.clear()

                startForegroundTracking()
            }
            ACTION_STOP -> {
                stopTracking()
            }
        }
        return START_STICKY
    }

    private fun startForegroundTracking() {
        acquireWakeLock()

        val notification = buildTrackingNotification(
            "Tracking your journey to ${destination?.name}",
            "Calculating distance..."
        )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        val locationRequest = LocationRequest.Builder(
            Priority.PRIORITY_HIGH_ACCURACY,
            8000L
        ).apply {
            setMinUpdateIntervalMillis(5000L)
            setWaitForAccurateLocation(false)
        }.build()

        try {
            fusedLocationClient.requestLocationUpdates(
                locationRequest,
                locationCallback,
                mainLooper
            )
        } catch (e: SecurityException) {
            stopTracking()
        }
    }

    private fun handleNewLocation(location: Location) {
        val dest = destination ?: return

        val destLocation = Location("dest").apply {
            latitude = dest.latitude
            longitude = dest.longitude
        }
        val distanceMeters = location.distanceTo(destLocation).toDouble()

        val speedKmh = if (location.hasSpeed() && location.speed > 0.3) {
            location.speed * 3.6
        } else 0.0

        if (speedKmh > 0) {
            recentSpeeds.add(speedKmh)
            if (recentSpeeds.size > 6) recentSpeeds.removeAt(0)
        }
        val avgSpeed = if (recentSpeeds.isNotEmpty()) recentSpeeds.average() else 0.0

        val etaMinutes = if (avgSpeed > 1.0) {
            (distanceMeters / 1000.0) / avgSpeed * 60.0
        } else {
            Double.MAX_VALUE
        }

        updateNotification(distanceMeters, etaMinutes, avgSpeed)
        broadcastUpdate(distanceMeters, etaMinutes)

        if (!preAlertFired && etaMinutes != Double.MAX_VALUE && etaMinutes <= dest.preAlertMinutes) {
            preAlertFired = true
            AlarmTriggerHelper.firePreAlert(this, dest.name, etaMinutes.roundToInt())
        }

        if (!finalAlarmFired && distanceMeters <= dest.arrivalRadiusMeters) {
            finalAlarmFired = true
            AlarmTriggerHelper.fireFinalAlarm(this, dest.name)
            stopTracking()
        }
    }

    private fun updateNotification(distanceMeters: Double, etaMinutes: Double, speedKmh: Double) {
        val distanceText = if (distanceMeters >= 1000) {
            "%.1f km away".format(distanceMeters / 1000)
        } else {
            "${distanceMeters.roundToInt()} m away"
        }
        val etaText = if (etaMinutes == Double.MAX_VALUE) "Calculating ETA..." else "ETA: ~${etaMinutes.roundToInt()} min"
        val speedText = if (speedKmh > 0) " • ${speedKmh.roundToInt()} km/h" else ""

        val notification = buildTrackingNotification(
            "Heading to ${destination?.name}",
            "$distanceText • $etaText$speedText"
        )
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, notification)
    }

    private fun buildTrackingNotification(title: String, content: String): Notification {
        val stopIntent = Intent(this, LocationTrackingService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val openAppIntent = Intent(this, MainActivity::class.java)
        val openAppPendingIntent = PendingIntent.getActivity(
            this, 0, openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, StationAlarmApp.TRACKING_CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(content)
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setOngoing(true)
            .setContentIntent(openAppPendingIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stopPendingIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun broadcastUpdate(distance: Double, eta: Double) {
        val intent = Intent(BROADCAST_TRIP_UPDATE).apply {
            putExtra(EXTRA_DISTANCE, distance)
            putExtra(EXTRA_ETA, eta)
            setPackage(packageName)
        }
        sendBroadcast(intent)
    }

    private fun acquireWakeLock() {
        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "StationAlarm::TrackingWakeLock"
        ).apply {
            acquire(12 * 60 * 60 * 1000L)
        }
    }

    private fun stopTracking() {
        fusedLocationClient.removeLocationUpdates(locationCallback)
        wakeLock?.let { if (it.isHeld) it.release() }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        super.onDestroy()
        wakeLock?.let { if (it.isHeld) it.release() }
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
