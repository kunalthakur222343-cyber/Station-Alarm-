package com.stationalarm.app.data

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.stationalarm.app.R

class SavedStationAdapter(
    private var stations: List<SavedStation>,
    private val onStationClick: (SavedStation) -> Unit,
    private val onDeleteClick: (SavedStation) -> Unit
) : RecyclerView.Adapter<SavedStationAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val nameText: TextView = view.findViewById(R.id.stationNameText)
        val deleteButton: ImageButton = view.findViewById(R.id.deleteStationButton)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_saved_station, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val station = stations[position]
        holder.nameText.text = station.name
        holder.itemView.setOnClickListener { onStationClick(station) }
        holder.deleteButton.setOnClickListener { onDeleteClick(station) }
    }

    override fun getItemCount(): Int = stations.size

    fun updateData(newStations: List<SavedStation>) {
        stations = newStations
        notifyDataSetChanged()
    }
}
