package com.stationalarm.app.data

import androidx.room.*

@Dao
interface SavedStationDao {

    @Query("SELECT * FROM saved_stations ORDER BY lastUsedTimestamp DESC")
    suspend fun getAll(): List<SavedStation>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(station: SavedStation): Long

    @Update
    suspend fun update(station: SavedStation)

    @Delete
    suspend fun delete(station: SavedStation)

    @Query("DELETE FROM saved_stations WHERE id = :id")
    suspend fun deleteById(id: Int)
}
