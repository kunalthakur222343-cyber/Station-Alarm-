package com.stationalarm.app.model

/**
 * Represents the destination the user wants to be woken up at.
 */
data class Destination(
    val name: String,
    val latitude: Double,
    val longitude: Double,
    // Distance in meters at which we trigger the "approaching" pre-alert (default 10 min worth)
    val preAlertMinutes: Int = 10,
    // Final radius in meters at which the full alarm rings (arrival)
    val arrivalRadiusMeters: Double = 500.0
)

/**
 * Holds live computed state of the trip, recalculated on every location update.
 */
data class TripStatus(
    val distanceRemainingMeters: Double,
    val currentSpeedKmh: Double,
    val etaMinutes: Double,
    val hasFiredPreAlert: Boolean = false,
    val hasFiredFinalAlarm: Boolean = false
)
