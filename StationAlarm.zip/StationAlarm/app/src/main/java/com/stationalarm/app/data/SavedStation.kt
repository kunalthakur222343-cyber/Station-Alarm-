package com.stationalarm.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "saved_stations")
data class SavedStation(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val latitude: Double,
    val longitude: Double,
    val preAlertMinutes: Int = 10,
    val arrivalRadiusMeters: Double = 500.0,
    val lastUsedTimestamp: Long = System.currentTimeMillis()
)
