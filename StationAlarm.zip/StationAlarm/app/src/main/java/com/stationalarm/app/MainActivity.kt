package com.stationalarm.app

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.libraries.places.api.Places
import com.google.android.libraries.places.api.model.Place
import com.google.android.libraries.places.widget.Autocomplete
import com.google.android.libraries.places.widget.model.AutocompleteActivityMode
import com.stationalarm.app.data.AppDatabase
import com.stationalarm.app.data.SavedStation
import com.stationalarm.app.data.SavedStationAdapter
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var map: GoogleMap
    private var selectedLatLng: LatLng? = null
    private var tripActive = false

    private lateinit var destinationText: TextView
    private lateinit var liveStatusText: TextView
    private lateinit var startButton: Button
    private lateinit var stopButton: Button
    private lateinit var saveStationButton: Button
    private lateinit var searchInput: EditText
    private lateinit var savedStationsButton: ImageButton
    private lateinit var savedStationsRecyclerView: RecyclerView

    private var selectedStationName: String = "Your stop"
    private val db by lazy { AppDatabase.getInstance(this) }
    private lateinit var savedStationsAdapter: SavedStationAdapter

    private val placesAutocompleteLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK && result.data != null) {
            val place = Autocomplete.getPlaceFromIntent(result.data!!)
            val latLng = place.latLng
            if (latLng != null) {
                selectedLatLng = latLng
                selectedStationName = place.name ?: "Your stop"
                searchInput.setText(selectedStationName)
                destinationText.text = "Selected: $selectedStationName"
                if (::map.isInitialized) {
                    map.clear()
                    map.addMarker(MarkerOptions().position(latLng).title(selectedStationName))
                    map.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 14f))
                }
            }
        }
    }

    private val tripUpdateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val distance = intent?.getDoubleExtra(LocationTrackingService.EXTRA_DISTANCE, 0.0) ?: return
            val eta = intent.getDoubleExtra(LocationTrackingService.EXTRA_ETA, 0.0)
            val distText = if (distance >= 1000) "%.1f km".format(distance / 1000) else "${distance.roundToInt()} m"
            val etaText = if (eta == Double.MAX_VALUE) "calculating..." else "${eta.roundToInt()} min"
            liveStatusText.text = "Distance: $distText • ETA: $etaText"
        }
    }

    private val locationPermissionLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val fineGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] ?: false
        if (fineGranted) {
            requestBackgroundLocationIfNeeded()
        } else {
            Toast.makeText(this, "Location permission is required for this app to work", Toast.LENGTH_LONG).show()
        }
    }

    private val backgroundLocationLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (!granted) {
            Toast.makeText(
                this,
                "Without 'Allow all the time' location access, the alarm won't work when your screen is off",
                Toast.LENGTH_LONG
            ).show()
        }
        requestNotificationPermissionIfNeeded()
    }

    private val notificationPermissionLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
    ) { /* proceed regardless */ requestBatteryOptimizationExemption() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        if (!Places.isInitialized()) {
            // Reuses the same key as Maps SDK in the manifest
            val apiKey = packageManager.getApplicationInfo(
                packageName, android.content.pm.PackageManager.GET_META_DATA
            ).metaData.getString("com.google.android.geo.API_KEY") ?: ""
            Places.initialize(applicationContext, apiKey)
        }

        destinationText = findViewById(R.id.selectedDestinationText)
        liveStatusText = findViewById(R.id.liveStatusText)
        startButton = findViewById(R.id.startTripButton)
        stopButton = findViewById(R.id.stopTripButton)
        saveStationButton = findViewById(R.id.saveStationButton)
        searchInput = findViewById(R.id.searchInput)
        savedStationsButton = findViewById(R.id.savedStationsButton)
        savedStationsRecyclerView = findViewById(R.id.savedStationsRecyclerView)

        val mapFragment = supportFragmentManager.findFragmentById(R.id.mapFragment) as SupportMapFragment
        mapFragment.getMapAsync(this)

        startButton.setOnClickListener { startTrip() }
        stopButton.setOnClickListener { stopTrip() }
        saveStationButton.setOnClickListener { saveCurrentStation() }

        searchInput.setOnClickListener { launchPlacesSearch() }
        searchInput.isFocusable = false // tapping always opens full autocomplete screen

        savedStationsButton.setOnClickListener { toggleSavedStationsList() }

        savedStationsAdapter = SavedStationAdapter(
            emptyList(),
            onStationClick = { station -> selectSavedStation(station) },
            onDeleteClick = { station -> deleteSavedStation(station) }
        )
        savedStationsRecyclerView.layoutManager = LinearLayoutManager(this)
        savedStationsRecyclerView.adapter = savedStationsAdapter

        requestAllPermissions()
    }

    private fun launchPlacesSearch() {
        val fields = listOf(Place.Field.ID, Place.Field.NAME, Place.Field.LAT_LNG)
        val intent = Autocomplete.IntentBuilder(AutocompleteActivityMode.FULLSCREEN, fields)
            .build(this)
        placesAutocompleteLauncher.launch(intent)
    }

    private fun toggleSavedStationsList() {
        if (savedStationsRecyclerView.visibility == android.view.View.VISIBLE) {
            savedStationsRecyclerView.visibility = android.view.View.GONE
            return
        }
        lifecycleScope.launch {
            val stations = db.savedStationDao().getAll()
            if (stations.isEmpty()) {
                Toast.makeText(this@MainActivity, "No saved stations yet — search and tap 'Save this station'", Toast.LENGTH_SHORT).show()
                return@launch
            }
            savedStationsAdapter.updateData(stations)
            savedStationsRecyclerView.visibility = android.view.View.VISIBLE
        }
    }

    private fun selectSavedStation(station: SavedStation) {
        val latLng = LatLng(station.latitude, station.longitude)
        selectedLatLng = latLng
        selectedStationName = station.name
        searchInput.setText(station.name)
        destinationText.text = "Selected: ${station.name}"
        savedStationsRecyclerView.visibility = android.view.View.GONE

        if (::map.isInitialized) {
            map.clear()
            map.addMarker(MarkerOptions().position(latLng).title(station.name))
            map.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 14f))
        }

        // bump last-used timestamp so frequently used stops float to top
        lifecycleScope.launch {
            db.savedStationDao().insert(station.copy(lastUsedTimestamp = System.currentTimeMillis()))
        }
    }

    private fun deleteSavedStation(station: SavedStation) {
        lifecycleScope.launch {
            db.savedStationDao().delete(station)
            val stations = db.savedStationDao().getAll()
            savedStationsAdapter.updateData(stations)
        }
    }

    private fun saveCurrentStation() {
        val dest = selectedLatLng
        if (dest == null) {
            Toast.makeText(this, "Pick a destination first (search or tap the map)", Toast.LENGTH_SHORT).show()
            return
        }
        lifecycleScope.launch {
            db.savedStationDao().insert(
                SavedStation(
                    name = selectedStationName,
                    latitude = dest.latitude,
                    longitude = dest.longitude
                )
            )
            Toast.makeText(this@MainActivity, "Saved: $selectedStationName", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onMapReady(googleMap: GoogleMap) {
        map = googleMap
        map.moveCamera(CameraUpdateFactory.newLatLngZoom(LatLng(28.6139, 77.2090), 5f)) // default: India view

        map.setOnMapClickListener { latLng ->
            map.clear()
            map.addMarker(MarkerOptions().position(latLng).title("Your stop"))
            selectedLatLng = latLng
            selectedStationName = "Custom point"
            searchInput.setText("")
            destinationText.text = "Selected: %.5f, %.5f".format(latLng.latitude, latLng.longitude)
        }
    }

    private fun startTrip() {
        val dest = selectedLatLng
        if (dest == null) {
            Toast.makeText(this, "Pick your destination on the map first", Toast.LENGTH_SHORT).show()
            return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) {
            requestAllPermissions()
            return
        }

        // Save trip state so BootReceiver can resume it if phone restarts mid-journey
        getSharedPreferences("trip_prefs", Context.MODE_PRIVATE).edit().apply {
            putBoolean("trip_active", true)
            putString("dest_name", selectedStationName)
            putFloat("dest_lat", dest.latitude.toFloat())
            putFloat("dest_lng", dest.longitude.toFloat())
            putInt("pre_alert_min", 10)
            putFloat("arrival_radius", 500f)
            apply()
        }

        val serviceIntent = Intent(this, LocationTrackingService::class.java).apply {
            action = LocationTrackingService.ACTION_START
            putExtra(LocationTrackingService.EXTRA_DEST_NAME, selectedStationName)
            putExtra(LocationTrackingService.EXTRA_DEST_LAT, dest.latitude)
            putExtra(LocationTrackingService.EXTRA_DEST_LNG, dest.longitude)
            putExtra(LocationTrackingService.EXTRA_PRE_ALERT_MIN, 10)
            putExtra(LocationTrackingService.EXTRA_ARRIVAL_RADIUS, 500.0)
        }
        ContextCompat.startForegroundService(this, serviceIntent)

        tripActive = true
        startButton.visibility = android.view.View.GONE
        stopButton.visibility = android.view.View.VISIBLE
        Toast.makeText(this, "Trip alarm started — relax and sleep!", Toast.LENGTH_SHORT).show()
    }

    private fun stopTrip() {
        val serviceIntent = Intent(this, LocationTrackingService::class.java).apply {
            action = LocationTrackingService.ACTION_STOP
        }
        startService(serviceIntent)

        getSharedPreferences("trip_prefs", Context.MODE_PRIVATE).edit()
            .putBoolean("trip_active", false).apply()

        tripActive = false
        startButton.visibility = android.view.View.VISIBLE
        stopButton.visibility = android.view.View.GONE
        liveStatusText.text = ""
    }

    // --- Permission cascade: fine location -> background location -> notifications -> battery exemption ---

    private fun requestAllPermissions() {
        val fineGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) ==
                PackageManager.PERMISSION_GRANTED
        if (!fineGranted) {
            locationPermissionLauncher.launch(
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
            )
        } else {
            requestBackgroundLocationIfNeeded()
        }
    }

    private fun requestBackgroundLocationIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_BACKGROUND_LOCATION) ==
                    PackageManager.PERMISSION_GRANTED
            if (!granted) {
                backgroundLocationLauncher.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
                return
            }
        }
        requestNotificationPermissionIfNeeded()
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) ==
                    PackageManager.PERMISSION_GRANTED
            if (!granted) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                return
            }
        }
        requestBatteryOptimizationExemption()
    }

    private fun requestBatteryOptimizationExemption() {
        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (!powerManager.isIgnoringBatteryOptimizations(packageName)) {
            try {
                val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                    data = Uri.parse("package:$packageName")
                }
                startActivity(intent)
            } catch (e: Exception) {
                // Some OEMs (Xiaomi, Oppo, Vivo) block this — handled gracefully, user can do it manually in Settings
            }
        }
    }

    override fun onResume() {
        super.onResume()
        registerReceiver(
            tripUpdateReceiver,
            IntentFilter(LocationTrackingService.BROADCAST_TRIP_UPDATE),
            Context.RECEIVER_NOT_EXPORTED
        )
    }

    override fun onPause() {
        super.onPause()
        try { unregisterReceiver(tripUpdateReceiver) } catch (e: Exception) { /* not registered */ }
    }
}
