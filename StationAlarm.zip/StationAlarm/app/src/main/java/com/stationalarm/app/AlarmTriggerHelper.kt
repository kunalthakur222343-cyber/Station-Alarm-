package com.stationalarm.app

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat

object AlarmTriggerHelper {

    /**
     * Sent N minutes before arrival — a normal (but high-priority) notification.
     * Vibrates + makes a short sound, doesn't need to wake the whole screen.
     */
    fun firePreAlert(context: Context, destinationName: String, etaMinutes: Int) {
        val intent = Intent(context, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            context, 1, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, StationAlarmApp.ALARM_CHANNEL_ID)
            .setContentTitle("Get ready!")
            .setContentText("$destinationName is about $etaMinutes min away")
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .setVibrate(longArrayOf(0, 400, 200, 400))
            .build()

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(2001, notification)
    }

    /**
     * The main event — fires on arrival. Launches a full-screen activity that:
     * - turns the screen on even if locked
     * - plays loud alarm sound even if the phone is on silent/vibrate (uses STREAM_ALARM)
     * - vibrates continuously
     * This is what actually "wakes the passenger up."
     */
    fun fireFinalAlarm(context: Context, destinationName: String) {
        val fullScreenIntent = Intent(context, AlarmRingActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_NO_USER_ACTION or
                    Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("destination_name", destinationName)
        }

        val fullScreenPendingIntent = PendingIntent.getActivity(
            context, 2, fullScreenIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, StationAlarmApp.ALARM_CHANNEL_ID)
            .setContentTitle("Wake up! Your stop has arrived")
            .setContentText(destinationName)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setFullScreenIntent(fullScreenPendingIntent, true)
            .setAutoCancel(true)
            .setOngoing(true)
            .build()

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(2002, notification)

        // Also launch directly — covers devices where full-screen intent from
        // notification gets delayed
        context.startActivity(fullScreenIntent)
    }
}
